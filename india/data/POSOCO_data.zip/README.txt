Title:      Daily Indian generation and demand data from POSOCO
Source:     Power System Operation Corporation Limited
SourceURL:  https://posoco.in/reports/daily-reports/
Processing: Tables A and G scraped from PDF documents; no further processing
Units:      All are in MU (million units = GWh), except {DemandMet,PeakShortage,MaximumDemand} which are in MW
Author:     Robbie Andrew @robbie_andrew folk.uio.no/roberan
Geography:  NR=Nothern Region, WR=Western Region, SR=Southern Region, ER=Eastern Region, NER=Northeast Region, TOTAL=India
Other:      DemandMet is demand met at 7pm or 8pm ('peak')
Other:      There are some data gaps due to missing reports
Other:      Please don't ask me to process other tables in these reports, or other reports
License:    All data are from POSOCO, but if you use them from this processed dataset then consider also citing me.
